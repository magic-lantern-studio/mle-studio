
#ifndef __TEXTURE_H_
#define __TEXTURE_H_

int  updateMaterialRegistry(void);

#endif /* __TEXTURE_H_ */
