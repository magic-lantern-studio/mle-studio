//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by app.rc
//
#define ID_TOOLBAR_ICONS                999
#define ID_FILE_NEW                     40002
#define ID_FILE_OPEN                    40003
#define ID_FILE_CLOSE                   40004
#define ID_FILE_SAVE                    40005
#define ID_FILE_SAVEAS                  40006
#define ID_FILE_PAGESETUP               40007
#define ID_FILE_PRINT                   40008
#define ID_VIEW_HIERACHY                40015
#define ID_VIEW_REGISTRY_MODELS         40018
#define ID_VIEW_REGISTRY_MATERIALS      40019
#define ID_VIEW_REGISTRY_TEXTUREMAPS    40020
#define ID_VIEW_REGISTRY_TABLES         40021
#define ID_VIEW_REGISTRY_MEMEORYCLASSES 40022
#define ID_VIEW_ORTHOGONAL_TOP          40023
#define ID_VIEW_ORTHOGONAL_BOTTOM       40024
#define ID_VIEW_ORTHOGONAL_LEFT         40025
#define ID_VIEW_ORTHOGONAL_RIGHT        40026
#define ID_VIEW_ORTHOGONAL_UP           40027
#define ID_VIEW_ORTHOGONAL_DOWN         40028
#define ID_FILE_EXIT                    40033
#define ID_HELP_ABOUT                   40035
#define ID_VIEW_CAMERA_MAIN             40036
#define ID_UPDATE_FORCE_ALL             40037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40039
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
