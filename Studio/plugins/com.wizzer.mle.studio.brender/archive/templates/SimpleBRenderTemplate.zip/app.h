#ifndef __APP_H_
#define __APP_H_


/*
 * IDs of strings in string table.
 */
#define IDS_APPNAME     1
#define IDS_DESCRIPTION 2
#define IDS_PLAYPRINT   3


#endif /* __APP_H_ */
