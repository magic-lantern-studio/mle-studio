//
// This file contains declarations for events and their callbacks which
// are specific to this title.
//

#ifndef __CALLBACK_H_
#define __CALLBACK_H_

// Include system header files.
#include <windows.h>

// Include Magic Lantern Runtime header files.
#include "mle/MleEventDispatcher.h"


//
// Event callback prototypes.
//

//
// Callbacks for Windows Messages.
int msgCreate(MleEvent event,void *callData,void *clientData);
int msgDestroy(MleEvent event,void *callData,void *clientData);
int msgActivateApp(MleEvent event,void *callData,void *clientData);
int msgPaint(MleEvent event,void *callData,void *clientData);

    
#endif __CALLBACK_H_
